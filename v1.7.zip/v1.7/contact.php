<?php
function PokazKontakt() 
{
    echo '
    <form action="contact.php" method="post">
        <label for="name">Imię i nazwisko:</label>
        <input type="text" id="name" name="name" required><br>
        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="message">Wiadomość:</label><br>
        <textarea id="message" name="message" required></textarea><br>
        <button type="submit">Wyślij</button>
    </form>';
}

function PrzypomnijHaslo() {
    $admin_email = "admin@example.com";
    $password = "TwojeHaslo123"; 
    
    $subject = "Przypomnienie hasła";
    $message = "Twoje hasło do panelu admina to: $password";
    $headers = "From: no-reply@example.com";

    mail($admin_email, $subject, $message, $headers);
}

function WyslijMailKontakt() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $message = htmlspecialchars($_POST['message']);

        $to = "kontakt@example.com";
        $subject = "Nowa wiadomość od $name";
        $body = "Imię i nazwisko: $name\nE-mail: $email\n\nWiadomość:\n$message";
        $headers = "From: $email";

        if (mail($to, $subject, $body, $headers)) {
            echo "Wiadomość została wysłana!";
        } else {
            echo "Wystąpił błąd. Spróbuj ponownie.";
        }
    }
}


?>