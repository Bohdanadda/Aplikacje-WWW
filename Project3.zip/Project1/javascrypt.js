        function showEmail() 
        {
            alert("Kontaktowy email: 169403@student.uwm.edu.pl");
        }