<main>

<?php
include('cfg.php');
?>
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$strona = '/html/glowna.html';

$idp = isset($_GET['idp']) ? $_GET['idp'] : 'glowna'; 


if(isset ($_GET['idp'] ))
{
    if ($_GET['idp']== 'glowna')
    {
        $strona = 'html\glowna.html';
    }
    elseif($_GET['idp'] == 'inne')
    {
        $strona = 'html\inne.html';
        
    }elseif($_GET['idp'] == 'menu')
    {
        $strona = 'html\menu.html';
        
    }elseif($_GET['idp'] == 'o_mnie')
    {
        $strona = 'html\o_mnie.html';
    }elseif($_GET['idp'] == 'filmy')
    {
        $strona = 'html\filmy.html';
    }
}

if (file_exists($strona))
{
    include($strona);

}else
{
    echo "Strona nie istnieje!!";
}

?>
</main>
