<?php
    $nr_indeksu = '169403';
    $nrGrupy = 'isi 1';

    echo'Bohdan Andreiev'.$nr_indeksu.'grupa'.$nrGrupy.'<br/><br/>';

    echo'Zastosowanie metody include() <br/>';
?>


<?php
    $a = 6;

    if($a > 5)
    {
        echo "A jest większa od 5";
    }
    elseif ($a == 5)
    {
        echo "A jest równa 5";
    }
    else 
    {
        echo "A nie jest większa od 5";
    }
?>