<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Moja Strona</title>
    <link rel="stylesheet" href="style.css"> <!-- Załączenie stylów -->
</head>
<body>
    <nav>
        <ul class="meni">
            <li><a href="index.php?idp=glowna">Główna</a></li>
            <li><a href="index.php?idp=inne">Inne</a></li>
            <li><a href="index.php?idp=menu">Menu</a></li>
            <li><a href="index.php?idp=o_mnie">O mnie</a></li>
            <li><a href="index.php?idp=filmy">Filmy</a></li>
            <li><a href="index.php?idp=kontakt">Kontakt</a></li>
            <li><a href="index.php?idp=koszyk">Koszyk</a></li>
        </ul>
    </nav>  