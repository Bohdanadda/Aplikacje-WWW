<?php
/**
 * Funkcje do obsługi formularza kontaktowego oraz zarządzania wiadomościami e-mail.
 */

/**
 * Funkcja wyświetlająca formularz kontaktowy.
 * Formularz umożliwia użytkownikowi przesłanie wiadomości na adres kontaktowy.
 */
function PokazKontakt() 
{
    echo '
    <form action="contact.php" method="post">
        <label for="name">Imię i nazwisko:</label>
        <input type="text" id="name" name="name" required><br>
        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required><br>
        <label for="message">Wiadomość:</label><br>
        <textarea id="message" name="message" required></textarea><br>
        <button type="submit">Wyślij</button>
    </form>';
}

/**
 * Funkcja wysyłająca przypomnienie hasła na adres e-mail administratora.
 * Używana do celów zarządzania panelem admina. Hasło powinno być przechowywane w bezpieczny sposób.
 */
function PrzypomnijHaslo() {
    // Adres e-mail administratora
    $admin_email = "admin@example.com";

    // UWAGA: Przechowywanie hasła w czystym tekście jest niebezpieczne!
    // Rozważ użycie hashowania (np. password_hash) oraz bazy danych do zarządzania hasłami.
    $password = "TwojeHaslo123"; 

    $subject = "Przypomnienie hasła";
    $message = "Twoje hasło do panelu admina to: $password";
    $headers = "From: no-reply@example.com";

    // Wysyłanie wiadomości e-mail
    mail($admin_email, $subject, $message, $headers);
}

/**
 * Funkcja obsługująca przesyłanie wiadomości z formularza kontaktowego.
 * Waliduje dane wejściowe oraz wysyła e-mail na wskazany adres kontaktowy.
 */
function WyslijMailKontakt() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Pobranie i walidacja danych wejściowych
        $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');

        // Sprawdzenie, czy dane są poprawne
        if (!$email) {
            echo "Nieprawidłowy adres e-mail.";
            return;
        }

        // Adres odbiorcy wiadomości
        $to = "kontakt@example.com";
        $subject = "Nowa wiadomość od $name";
        $body = "Imię i nazwisko: $name\nE-mail: $email\n\nWiadomość:\n$message";
        $headers = "From: $email";

        // Wysyłanie wiadomości e-mail
        if (mail($to, $subject, $body, $headers)) {
            echo "Wiadomość została wysłana!";
        } else {
            echo "Wystąpił błąd. Spróbuj ponownie.";
        }
    }
}
?>
