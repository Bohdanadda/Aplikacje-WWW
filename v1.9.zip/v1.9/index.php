<?php
/**
 * Plik główny obsługujący logikę wyświetlania treści na stronie.
 * 
 * Opis: Ten plik dynamicznie wczytuje zawartość stron na podstawie parametrów
 *       przesyłanych metodą $_GET. Używa plików HTML jako szablonów treści.
 */

include('cfg.php'); // Załączenie pliku konfiguracyjnego

// Włączanie raportowania błędów - ułatwia debugowanie podczas rozwoju
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Ustawienie domyślnej ścieżki do pliku głównej strony
$strona = '/html/glowna.html';

/**
 * Pobranie parametru 'idp' z metody $_GET.
 * Jeżeli parametr nie istnieje, ustawiamy domyślną wartość 'glowna'.
 * Parametr jest wstępnie filtrowany, aby zapobiec podstawowym atakom typu injection.
 */
$idp = isset($_GET['idp']) ? htmlspecialchars($_GET['idp'], ENT_QUOTES, 'UTF-8') : 'glowna';

/**
 * Mapowanie wartości parametru 'idp' na odpowiednie pliki HTML.
 * Funkcja obsługuje różne sekcje strony na podstawie przesłanego parametru.
 */
if (isset($idp)) {
    switch ($idp) {
        case 'glowna':
            $strona = 'html/glowna.html';
            break;
        case 'inne':
            $strona = 'html/inne.html';
            break;
        case 'menu':
            $strona = 'html/menu.html';
            break;
        case 'o_mnie':
            $strona = 'html/o_mnie.html';
            break;
        case 'filmy':
            $strona = 'html/filmy.html';
            break;
        default:
            $strona = ''; // Wartość domyślna dla nieznanego parametru
            break;
    }
}

/**
 * Weryfikacja, czy plik istnieje przed jego załączeniem.
 * W przypadku braku pliku wyświetlany jest komunikat o błędzie.
 */
if (!empty($strona) && file_exists($strona)) {
    include($strona);
} else {
    echo "Strona nie istnieje!!";
}
?>
