$("#animacjaTestowa1").on("click", function()
{
    $(this).animate
    (
        {
            with: "500px",
            opacity: 0.4,
            fontSize: "3em",
            borderWidth: "10px"
        },1500
    );
});


