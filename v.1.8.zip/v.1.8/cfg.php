<?php
/**
 * Plik konfiguracji połączenia z bazą danych.
 */

// Dane do połączenia z bazą danych
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$baza = 'moja_strona';

// Nawiązanie połączenia z bazą danych
$link = mysqli_connect($dbhost, $dbuser, $dbpass, $baza);

// Sprawdzenie poprawności połączenia
if (!$link) {
    die('<b>Przerwane połączenie: </b>' . mysqli_connect_error());
}

// Weryfikacja wybranej bazy danych
if (!mysqli_select_db($link, $baza)) {
    die('Nie wybrano bazy danych: ' . mysqli_error($link));
}

// Użytkownik administracyjny (przykład)
$login = 'admin';

// UWAGA: Przechowywanie haseł w czystym tekście jest niebezpieczne!
// Hasło poniżej powinno być zahaszowane za pomocą password_hash.
$pass = password_hash('password', PASSWORD_DEFAULT);
?>
